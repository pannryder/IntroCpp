#pragma once


//Defualt Item class
class Item 
{
public:
    Item();
    ~Item();
    void Description() const;
    void Use();
};