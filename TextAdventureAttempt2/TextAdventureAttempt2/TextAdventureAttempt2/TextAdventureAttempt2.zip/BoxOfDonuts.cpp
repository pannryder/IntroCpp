#include"BoxOfDonuts.h"
#include <iostream>

using std::cout;

BoxOfDonuts::BoxOfDonuts(int initialCount) 
    : count(initialCount) 
{
}

void BoxOfDonuts::Description() const 
{
    cout << "A box of assorted donuts with an array of colors and flavors.\n";
}
void BoxOfDonuts::Use() 
{
    if (count > 0) 
    {
        count--;
        cout << "You consume a donut, each bite tingling your senses. The amount of donuts remaining is : " << count << ".\n";
    }
    else 
    {
        cout << "All donuts are gone. How sad...\n";
    }
}