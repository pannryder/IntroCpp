#include "Item.h"

Item::Item() 
{
}

Item::~Item()
{
}

void Item::Description() const 
{
}
void Item::Use() 
{
}
